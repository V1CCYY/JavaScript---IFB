const alunos = [];

const qtdAlunos = parseInt(prompt("Digite a quantidade de alunos da turma:"));

for(let i = 0; i < qtdAlunos; i++){
    
}