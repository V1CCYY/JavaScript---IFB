let quantAlunos;                 
let cont = 0;                    
let mediaAluno = 0;              
let mediaTurma = 0;              
let quantAlunoAprovados = 0;     
let quantAlunosReprovados = 0;   

alert("Bem-vindo ao sistema de controle de notas!");

quantAlunos = parseInt(prompt("Digite a quantidade de alunos da turma:"));

let aluno = [];                  
let medias = [];                 
let armazenaDadosAlunos = [];    

while (cont < quantAlunos) {

    mediaAluno = 0;  
    aluno = [];      

    for (let i = 0; i < 5; i++) {
        if (i == 0) {
            aluno[i] = prompt("Digite o nome do aluno:");
        } 
        else if (i > 0 && i <= 4) {
            aluno[i] = parseFloat(prompt("Digite a nota do " + i + "° Bimestre:"));
            mediaAluno += aluno[i];
        }
    }

    mediaAluno /= 4;
    mediaTurma += mediaAluno;
    medias.push(mediaAluno);
    armazenaDadosAlunos.push(aluno);

    if (mediaAluno >= 6) {
        quantAlunoAprovados++;    
    } else {
        quantAlunosReprovados++;  
    }

    cont++;
}

alert("Resultados no Console:");
console.log("===== RESULTADOS =====");

for (let i = 0; i < armazenaDadosAlunos.length; i++) {
    console.log(
        "Aluno: " + armazenaDadosAlunos[i][0] +
        " | Média: " + medias[i].toFixed(2));
}

console.log("Quantidade de alunos aprovados: " + quantAlunoAprovados);
console.log("Quantidade de alunos reprovados: " + quantAlunosReprovados);
console.log("Média da turma: " + (mediaTurma / quantAlunos).toFixed(2));
